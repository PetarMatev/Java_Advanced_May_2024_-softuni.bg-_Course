package _06_Defining_Classes._02_Exercise._02_Company_Roster;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import static java.util.stream.Collectors.groupingBy;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        LinkedList<Employee> listOfEmployees = new LinkedList<>();


        int num = Integer.parseInt(scan.nextLine());
        for (int i = 0; i < num; i++) {
            String[] info = scan.nextLine().split("\\s+");
            int size = info.length;
            String name = info[0];
            double salary = Double.parseDouble(info[1]);
            String position = info[2];
            String department = info[3];

            Employee employee;

            if (size == 4) {
                employee = new Employee(name, salary, position, department);
            } else if (size == 5) {
                if (info[4].length() > 3) {
                    String email = info[4];
                    employee = new Employee(name, salary, position, department, email);
                } else {
                    int age = Integer.parseInt(info[4]);
                    employee = new Employee(name, salary, position, department, age);
                }
            } else {
                String email = info[4];
                int age = Integer.parseInt(info[5]);
                employee = new Employee(name, salary, position, department, email, age);
            }
            listOfEmployees.add(employee);
        }

        // use groupingBy in order to collect into Map of Department each employee in the list
        Map<String, List<Employee>> departmentMap = listOfEmployees
                .stream()
                .collect(groupingBy(Employee::getDepartment));

        Map.Entry<String, List<Employee>> highestSalaryDepartment = departmentMap.entrySet()
                .stream()
                .sorted((employee1, employee2) -> {
                    double employee1AverageSalary = employee1.getValue().stream().mapToDouble(Employee::getSalary)
                            .average()
                            .getAsDouble();

                    double employee2AverageSalary = employee2.getValue().stream().mapToDouble(Employee::getSalary)
                            .average()
                            .getAsDouble();

                    return Double.compare(employee2AverageSalary, employee1AverageSalary);
                })

                .findFirst()
                .orElse(null);


        System.out.printf("Highest Average Salary: %s%n", highestSalaryDepartment.getKey());
        highestSalaryDepartment.getValue()
                .stream()
                .sorted((e1, e2) -> Double.compare(e2.getSalary(), e1.getSalary()))
                .forEach(System.out::println);
    }
}
