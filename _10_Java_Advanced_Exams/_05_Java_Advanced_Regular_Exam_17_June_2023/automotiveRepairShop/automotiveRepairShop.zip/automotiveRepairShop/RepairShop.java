package automotiveRepairShop;

import java.util.ArrayList;
import java.util.List;

public class RepairShop {

    private int capacity;
    private List<Vehicle> vehicles;

    public RepairShop(int capacity) {
        this.capacity = capacity;
        this.vehicles = new ArrayList<>();
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    //•	Method addVehicle(Vehicle vehicle) – adds an entity to the collection of Vehicles, if the Capacity allows it.
    public void addVehicle(Vehicle vehicle) {
        if (vehicles.size() < capacity) {
            vehicles.add(vehicle);
        }
    }

    //•	Method removeVehicle(String vin) – removes a vehicle by given vin, if such exists, and returns boolean (true if it is removed, otherwise – false)
    public boolean removeVehicle(String vin) {
        return vehicles.removeIf(v -> v.getVIN().equals(vin));
    }

    //•	Method getCount() – returns the number of vehicles, registered in the RepairShop
    public int getCount() {
        return vehicles.size();
    }

    //•	Method getLowestMileage() – returns the Vehicle with the lowest value of Mileage property.
    public Vehicle getLowestMileage() {
        return vehicles.stream().min((v1, v2) -> Integer.compare(v1.getMileage(), v2.getMileage())).orElse(null);
    }

    //•	Method report() – returns a string in the following format:
    public String report() {
        StringBuilder report = new StringBuilder();
        report.append("Vehicles in the preparatory\n");
        for (Vehicle vehicle : vehicles) {
            report.append(vehicle);
            report.append(System.lineSeparator());
        }

        return report.toString();
    }
}
