package Java_Advanced_May_2024._09_Iterators_and_Comparators._02_Exercise;

import java.util.Iterator;
import java.util.List;

public class ListyIterator<T> implements Iterable<T> {
    private int internalIndex;
    private List<T> elements;
    private Iterator<T> ListyIterator;

    public ListyIterator(T... elements) {
        this.elements = List.of(elements);
        this.internalIndex = 0;
        this.ListyIterator = iterator();
    }


    public boolean move() {
        if (this.ListyIterator.hasNext()) {
            this.internalIndex++;
            ListyIterator.next();
            return true;
        }
        return false;
    }

    public boolean hasNext() {
        return ListyIterator.hasNext();
    }

    public void print() {
        if (this.elements.isEmpty()) {
            throw  new IllegalStateException("Invalid Operation!");
        }
        System.out.println(this.elements.get(internalIndex));
    }


    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() { // Annonymous class

            int index = 0;


            @Override
            public boolean hasNext() {
                return this.index < elements.size() - 1;
            }

            @Override
            public T next() {
                return elements.get(index++);
            }
        };
    }
}
